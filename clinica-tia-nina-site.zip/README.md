# Site da Clínica de Beleza Tia Nina

Site estático (HTML, CSS e JavaScript simples, sem passo de compilação). Funciona em qualquer alojamento: basta enviar a pasta inteira.

## O que já funciona (sem configurar nada)

- Banner do salão como parte principal da página inicial
- Serviços (os do banner), galeria com as 9 fotografias, filtros por categoria e fotografia ampliada
- Botão "Gostei deste estilo — quero marcar" que abre o WhatsApp com a mensagem
- Formulário de pedido de marcação com validação (a hora tem de estar dentro do horário desse dia)
- Botão flutuante do WhatsApp, localização (mapa e botão "Ver localização"), horário com "aberto agora" calculado pela hora de Angola
- SEO básico (título, descrição, dados estruturados do salão)

## O que precisa de configuração

**Só o painel da galeria** (`admin.html`) precisa de configuração, para a proprietária adicionar e remover fotografias sem mexer no código. Até lá, o site mostra as 9 fotografias incluídas.

### Ativar a galeria (Supabase, gratuito)

1. Cria uma conta em supabase.com e um projeto novo.
2. **Authentication → Users → Add user → Create new user**: email e palavra-passe da proprietária (marca "Auto Confirm User").
3. **Authentication → Sign In / Providers**: desativa **"Allow new users to sign up"**, para ninguém mais criar conta.
4. Abre `supabase/setup.sql`, troca `EMAIL_DA_PROPRIETARIA@exemplo.com` (5 vezes) pelo email do passo 2, e executa o ficheiro em **SQL Editor → New query → Run**.
5. **Project Settings → API**: copia o **Project URL** e a chave **anon public** para `js/config.js`, no bloco `TN.SUPABASE`.
   - Nunca coloques a chave `service_role` no site (é secreta).
6. Publica o site e abre `https://o-teu-endereco/admin.html`. Entra e carrega em **"Importar as fotografias iniciais"** para passar a gerir também as 9 fotografias.

Como funciona a segurança: qualquer pessoa pode **ver** a galeria, mas só a conta com o email da proprietária consegue **adicionar ou remover** (políticas RLS no `setup.sql`). A pasta de imagens só aceita JPG, PNG e WebP até 5 MB.

## Publicar o site

Qualquer destes serve (arrastar a pasta do projeto): Netlify, Cloudflare Pages, Vercel ou GitHub Pages. Não abras o `index.html` com duplo clique para testar a galeria do painel: usa o endereço publicado (ou `python3 -m http.server` na pasta).

Depois de ter o endereço próprio, em `index.html` troca `banner.png` (nas etiquetas `og:image` e `image`) pelo endereço completo, por exemplo `https://teusite.com/banner.png`, e acrescenta a etiqueta `<link rel="canonical" href="https://teusite.com/">`.

## Como alterar o conteúdo

| O quê | Onde |
|---|---|
| WhatsApp, Instagram, Facebook, localização | `js/config.js` → `TN.SALON` |
| Horário | `js/config.js` → `TN.HOURS` |
| Serviços, descrições e preços | `js/config.js` → `TN.SERVICES` (`price: null` mostra "Preço sob consulta") |
| Testemunhos reais | `js/config.js` → `TN.TESTIMONIALS` |
| Texto "Sobre nós" | `index.html`, secção `#sobre` |
| Cores e letras | `css/styles.css`, no início (`:root`) |

## Por confirmar

- Morada exata e pin do mapa: o mapa faz uma pesquisa por "Bairro Ângelo, Cacuaco, Angola" (não há coordenadas inventadas).
- Instagram e Facebook: aparecem como "em breve" até serem preenchidos.
- Preços: nenhum foi inventado. As fotografias das perucas trazem preços escritos (10 mil e 12 mil Kz), mas o site não os repete.
- Testemunhos: o site mostra um convite para partilhar a experiência até existirem opiniões reais.

## Privacidade

O formulário não guarda dados: o pedido segue do WhatsApp da cliente para o do salão. Nenhum dado de clientes passa por servidores do site.
