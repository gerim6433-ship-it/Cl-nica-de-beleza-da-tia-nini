/* Funções de apoio: horário (hora de Angola), WhatsApp e escape de texto. */
(function () {
  const TN = (window.TN = window.TN || {});
  const { SALON, HOURS } = TN;

  /* ---------- Horário ---------- */
  const WD = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

  TN.toMin = (t) => {
    const [h, m] = t.split(':').map(Number);
    return h * 60 + m;
  };
  TN.fmtTime = (t) => {
    const [h, m] = t.split(':');
    return `${Number(h)}h${m}`;
  };

  /** Dia da semana, minutos e data (AAAA-MM-DD) na hora local de Angola. */
  TN.nowInLuanda = (date = new Date()) => {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: SALON.timezone,
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(date);
    const g = (t) => parts.find((p) => p.type === t).value;
    let hour = Number(g('hour'));
    if (hour === 24) hour = 0;
    return {
      day: WD[g('weekday')],
      minutes: hour * 60 + Number(g('minute')),
      iso: `${g('year')}-${g('month')}-${g('day')}`,
    };
  };

  TN.hoursFor = (day) => HOURS.find((h) => h.day === day);

  TN.dayOfISO = (iso) => {
    const [y, m, d] = iso.split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  };

  TN.openStatus = (date = new Date()) => {
    const n = TN.nowInLuanda(date);
    const today = TN.hoursFor(n.day);
    if (n.minutes >= TN.toMin(today.open) && n.minutes < TN.toMin(today.close)) {
      return { open: true, text: `Aberto agora · fecha às ${TN.fmtTime(today.close)}` };
    }
    if (n.minutes < TN.toMin(today.open)) {
      return { open: false, text: `Fechado · abre hoje às ${TN.fmtTime(today.open)}` };
    }
    const next = TN.hoursFor((n.day + 1) % 7);
    return { open: false, text: `Fechado · abre amanhã às ${TN.fmtTime(next.open)}` };
  };

  /* ---------- WhatsApp ---------- */
  TN.waLink = (text) =>
    text ? `https://wa.me/${SALON.whatsapp}?text=${encodeURIComponent(text)}` : `https://wa.me/${SALON.whatsapp}`;

  TN.msgGeneral = () => `Olá, ${SALON.name}! Gostaria de saber mais sobre os vossos serviços.`;

  TN.msgService = (serviceName) =>
    `Olá, ${SALON.name}! Gostaria de marcar o serviço: ${serviceName}. Qual é a disponibilidade?`;

  TN.msgGalleryItem = (label, imageUrl) =>
    `Olá, ${SALON.name}! Gostei deste estilo da vossa galeria${label ? ` (${label})` : ''} e gostaria de marcar.` +
    (imageUrl ? `\nFoto: ${imageUrl}` : '') +
    `\nPodem ajudar-me?`;

  TN.msgBooking = (d) =>
    `Olá, ${SALON.name}! Gostaria de solicitar uma marcação.\n\n` +
    `Nome: ${d.name}\n` +
    `Telefone: ${d.phone}\n` +
    `Serviço: ${d.service}\n` +
    `Data pretendida: ${d.date}\n` +
    `Hora pretendida: ${d.time}\n` +
    `Observações: ${d.notes || 'Sem observações'}\n\n` +
    `Aguardo a confirmação. Obrigada!`;

  TN.msgTestimonial = () =>
    `Olá, ${SALON.name}! Gostaria de partilhar a minha experiência no vosso salão.`;

  /* ---------- Utilitários ---------- */
  TN.el = (tag, attrs = {}, children = []) => {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    }
    for (const c of [].concat(children)) {
      if (c === null || c === undefined) continue;
      node.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return node;
  };

  TN.CATEGORIES = [
    { id: 'penteados', label: 'Penteados' },
    { id: 'unhas', label: 'Unhas' },
    { id: 'maquilhagem', label: 'Maquilhagem' },
    { id: 'perucas', label: 'Perucas' },
    { id: 'salao', label: 'O nosso espaço' },
    { id: 'outros', label: 'Outros' },
  ];
  TN.categoryLabel = (id) => (TN.CATEGORIES.find((c) => c.id === id) || {}).label || 'Outros';
})();
