/*
 * CONFIGURAÇÃO DO SITE — Clínica de Beleza Tia Nina
 * ------------------------------------------------------------
 * É aqui que se altera o que aparece no site: contacto, horário,
 * serviços, preços, redes sociais e testemunhos.
 * (As fotografias da galeria gerem-se no painel: /admin.html)
 */
(function () {
  const TN = (window.TN = window.TN || {});

  TN.SALON = {
    name: 'Clínica de Beleza Tia Nina',
    whatsapp: '244937364609', // formato internacional, sem espaços nem símbolos
    whatsappDisplay: '93736-46-09',
    place: 'Cacuaco, bairro Ângelo, Angola',
    mapsQuery: 'Bairro Ângelo, Cacuaco, Angola', // pesquisa — sem coordenadas inventadas
    timezone: 'Africa/Luanda',
    instagram: '', // ex.: 'https://www.instagram.com/...'  (vazio = mostra "em breve")
    facebook: '', // ex.: 'https://www.facebook.com/...'
  };

  // 0 = domingo … 6 = sábado
  TN.HOURS = [
    { day: 1, label: 'Segunda-feira', open: '18:30', close: '22:00' },
    { day: 2, label: 'Terça-feira', open: '18:30', close: '22:00' },
    { day: 3, label: 'Quarta-feira', open: '18:30', close: '22:00' },
    { day: 4, label: 'Quinta-feira', open: '18:30', close: '22:00' },
    { day: 5, label: 'Sexta-feira', open: '18:30', close: '22:00' },
    { day: 6, label: 'Sábado', open: '18:30', close: '22:00' },
    { day: 0, label: 'Domingo', open: '12:30', close: '21:00' },
  ];

  /*
   * SERVIÇOS — os que constam do banner do salão.
   * price: null  → mostra "Preço sob consulta". Para mostrar um preço,
   *               escreve por exemplo  price: '10 000 Kz'
   * image: ficheiro da pasta gallery/ (ou null para um cartão com ícone)
   * visible: false esconde o serviço sem o apagar.
   */
  TN.SERVICES = [
    {
      id: 'penteado-trancas',
      name: 'Penteado e tranças',
      description: 'Penteados e tranças para o dia a dia ou para uma ocasião especial.',
      price: null,
      image: 'gallery/penteado-rosas-3-sm.webp',
      icon: 'hair',
      visible: true,
    },
    {
      id: 'preparacao-noiva',
      name: 'Preparação de noiva',
      description: 'Penteado e maquilhagem para o teu grande dia. Fala connosco para combinar os detalhes.',
      price: null,
      image: 'gallery/penteado-rosas-1-sm.webp',
      icon: 'sparkle',
      visible: true,
    },
    {
      id: 'maquilhagem',
      name: 'Maquilhagem',
      description: 'Maquilhagem para realçar o teu olhar e a tua beleza natural.',
      price: null,
      image: 'gallery/maquilhagem-sm.webp',
      icon: 'brush',
      visible: true,
    },
    {
      id: 'manicure-pedicure',
      name: 'Manicure e pedicure',
      description: 'Cuidado e decoração para as tuas unhas, com acabamento cuidado.',
      price: null,
      image: 'gallery/unhas-vermelhas-sm.webp',
      icon: 'nail',
      visible: true,
    },
    {
      id: 'pestanas',
      name: 'Aplicação de pestanas',
      description: 'Aplicação de pestanas para um olhar mais marcante.',
      price: null,
      image: null,
      icon: 'eye',
      visible: true,
    },
    {
      id: 'perucas',
      name: 'Perucas e aplicação',
      description: 'Perucas com ou sem aplicação. Pergunta-nos pelos modelos disponíveis.',
      price: null,
      image: 'gallery/peruca-cacheada-sm.webp',
      icon: 'hair',
      visible: true,
    },
    {
      id: 'barbearia',
      name: 'Barbearia',
      description: 'Cortes e cuidados de barba.',
      price: null,
      image: null,
      icon: 'scissors',
      visible: true,
    },
    {
      id: 'produtos',
      name: 'Produtos de beleza e cosméticos',
      description: 'Venda de produtos de beleza e cosméticos.',
      price: null,
      image: null,
      icon: 'bag',
      visible: true,
    },
  ];

  /*
   * TESTEMUNHOS — só avaliações REAIS, com autorização da cliente.
   * Exemplo:  { name: 'Nome da cliente', text: 'O que ela disse.' }
   */
  TN.TESTIMONIALS = [];

  /*
   * SUPABASE — necessário apenas para o painel da galeria (admin.html).
   * Preenche com o "Project URL" e a chave "anon public".
   * NUNCA coloques aqui a chave "service_role" (é secreta).
   * Ver README.md, passo a passo.
   */
  TN.SUPABASE = {
    url: '',
    anonKey: '',
  };
})();
