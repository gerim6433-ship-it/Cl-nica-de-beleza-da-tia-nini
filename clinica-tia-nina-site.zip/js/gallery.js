/* Galeria pública: fotos iniciais + fotos geridas no painel (Supabase). */
(function () {
  const TN = (window.TN = window.TN || {});
  const { el } = TN;

  /* Fotos reais enviadas pela proprietária (ordem de apresentação). */
  TN.SEED_GALLERY = [
    { name: 'penteado-rosas-3', category: 'penteados', caption: 'Penteado com rosas', w: 1050, h: 1400 },
    { name: 'unhas-vermelhas', category: 'unhas', caption: 'Unhas vermelhas com detalhes dourados', w: 720, h: 540 },
    { name: 'maquilhagem', category: 'maquilhagem', caption: 'Maquilhagem', w: 581, h: 1032 },
    { name: 'penteado-rosas-1', category: 'penteados', caption: 'Penteado com rosas', w: 1050, h: 1400 },
    { name: 'penteado-rosas-2', category: 'penteados', caption: 'Penteado com rosas', w: 1050, h: 1400 },
    { name: 'salao-interior', category: 'salao', caption: 'O nosso espaço', w: 720, h: 960 },
    { name: 'peruca-ondulada', category: 'perucas', caption: 'Peruca ondulada', w: 720, h: 721 },
    { name: 'peruca-cacheada', category: 'perucas', caption: 'Peruca cacheada', w: 720, h: 749 },
    { name: 'unhas-verdes', category: 'unhas', caption: 'Unhas em verde neon', w: 720, h: 900 },
  ];

  const seedItems = () =>
    TN.SEED_GALLERY.map((s) => ({
      id: `seed-${s.name}`,
      category: s.category,
      caption: s.caption,
      src: `gallery/${s.name}.webp`,
      thumb: `gallery/${s.name}-sm.webp`,
      w: s.w,
      h: s.h,
    }));

  const dbItems = (rows) =>
    rows.map((r) => ({
      id: r.id,
      category: r.category,
      caption: r.caption || '',
      src: TN.sb.publicUrl(r.image_path),
      thumb: TN.sb.publicUrl(r.thumb_path),
    }));

  TN.loadGallery = async () => {
    if (TN.sb.isConfigured()) {
      try {
        const rows = await TN.sb.listItems();
        if (rows.length) return { items: dbItems(rows), fallback: false };
      } catch (e) {
        return { items: seedItems(), fallback: true };
      }
    }
    return { items: seedItems(), fallback: false };
  };

  /* ---------- Interface ---------- */
  let items = [];
  let visible = [];
  let current = 0;
  let lastFocus = null;

  const grid = () => document.getElementById('gallery-grid');
  const dialog = () => document.getElementById('lightbox');

  function label(item) {
    return item.caption || TN.categoryLabel(item.category);
  }

  function renderGrid(filter) {
    const g = grid();
    g.replaceChildren();
    visible = items.filter((i) => filter === 'todos' || i.category === filter);
    if (!visible.length) {
      g.append(el('p', { class: 'gallery-empty', text: 'Ainda não há fotografias nesta categoria.' }));
      return;
    }
    visible.forEach((item, idx) => {
      const img = el('img', {
        src: item.thumb,
        alt: item.caption ? item.caption : `Trabalho de ${TN.categoryLabel(item.category).toLowerCase()} da ${TN.SALON.name}`,
        loading: idx < 4 ? 'eager' : 'lazy',
        decoding: 'async',
        width: item.w,
        height: item.h,
      });
      const btn = el(
        'button',
        {
          type: 'button',
          class: 'g-item reveal',
          'aria-label': `Ampliar fotografia: ${label(item)}`,
          onclick: () => openLightbox(idx),
        },
        [img, el('span', { class: 'g-cap' }, [label(item)])]
      );
      g.append(btn);
    });
    if (window.TN.observeReveal) window.TN.observeReveal(g);
  }

  function renderFilters() {
    const wrap = document.getElementById('gallery-filters');
    wrap.replaceChildren();
    const present = new Set(items.map((i) => i.category));
    const cats = [{ id: 'todos', label: 'Todos' }, ...TN.CATEGORIES.filter((c) => present.has(c.id))];
    cats.forEach((c, i) => {
      wrap.append(
        el('button', {
          type: 'button',
          class: 'chip' + (i === 0 ? ' is-active' : ''),
          'data-cat': c.id,
          'aria-pressed': i === 0 ? 'true' : 'false',
          text: c.label,
          onclick: (e) => {
            wrap.querySelectorAll('.chip').forEach((b) => {
              b.classList.remove('is-active');
              b.setAttribute('aria-pressed', 'false');
            });
            e.currentTarget.classList.add('is-active');
            e.currentTarget.setAttribute('aria-pressed', 'true');
            renderGrid(c.id);
          },
        })
      );
    });
  }

  /* ---------- Ampliar fotografia ---------- */
  function showLightbox() {
    const item = visible[current];
    const d = dialog();
    const img = d.querySelector('.lb-img');
    img.src = item.src;
    img.alt = label(item);
    d.querySelector('.lb-cap').textContent = `${label(item)} · ${TN.categoryLabel(item.category)}`;
    d.querySelector('.lb-count').textContent = `${current + 1} / ${visible.length}`;
    const abs = /^https:/.test(location.protocol) ? new URL(item.src, location.href).href : '';
    d.querySelector('.lb-book').href = TN.waLink(TN.msgGalleryItem(label(item), abs));
    const multi = visible.length > 1;
    d.querySelector('.lb-prev').hidden = !multi;
    d.querySelector('.lb-next').hidden = !multi;
  }

  function openLightbox(idx) {
    current = idx;
    lastFocus = document.activeElement;
    const d = dialog();
    showLightbox();
    if (typeof d.showModal === 'function') d.showModal();
    else d.setAttribute('open', '');
    document.documentElement.classList.add('no-scroll');
  }

  function closeLightbox() {
    const d = dialog();
    if (typeof d.close === 'function') d.close();
    else d.removeAttribute('open');
  }

  function step(delta) {
    current = (current + delta + visible.length) % visible.length;
    showLightbox();
  }

  function initLightbox() {
    const d = dialog();
    d.querySelector('.lb-close').addEventListener('click', closeLightbox);
    d.querySelector('.lb-prev').addEventListener('click', () => step(-1));
    d.querySelector('.lb-next').addEventListener('click', () => step(1));
    d.addEventListener('click', (e) => {
      if (e.target === d) closeLightbox(); // clique no fundo escuro
    });
    d.addEventListener('close', () => {
      document.documentElement.classList.remove('no-scroll');
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    });
    d.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') step(-1);
      if (e.key === 'ArrowRight') step(1);
    });
    // deslizar no telemóvel
    let x0 = null;
    d.addEventListener('touchstart', (e) => (x0 = e.touches[0].clientX), { passive: true });
    d.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50 && visible.length > 1) step(dx < 0 ? 1 : -1);
      x0 = null;
    });
  }

  TN.initGallery = async () => {
    initLightbox();
    const status = document.getElementById('gallery-status');
    status.textContent = 'A carregar fotografias…';
    const { items: loaded, fallback } = await TN.loadGallery();
    items = loaded;
    status.textContent = fallback
      ? 'Não foi possível atualizar a galeria agora. A mostrar as fotografias principais.'
      : '';
    renderFilters();
    renderGrid('todos');
  };
})();
