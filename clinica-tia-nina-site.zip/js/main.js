/* Página principal: serviços, marcação, horário, navegação e animações. */
(function () {
  const TN = (window.TN = window.TN || {});
  const { SALON, HOURS, SERVICES, TESTIMONIALS, el } = TN;
  const $ = (id) => document.getElementById(id);

  /* ---------- Ícones (cartões sem fotografia) ---------- */
  const ICONS = {
    scissors:
      '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M8.12 8.12 20 20M14.8 14.8 20 9.5M8.12 15.88 12 12"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/><path d="M12 2v1.5M5 4l1 1.2M19 4l-1 1.2"/>',
    bag: '<path d="M6 7h12l1 13H5L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/>',
    brush: '<path d="M18 3 9 12l3 3 9-9-3-3Z"/><path d="M9 12c-3 0-5 2-5 5 0 1.5-1 3-1 3s5 1 7-1c1.5-1.5 2-3 1-4"/>',
    nail: '<path d="M9 21V9a3 3 0 0 1 6 0v12"/><path d="M9 14h6"/>',
    hair: '<path d="M5 20c0-8 2-15 7-15s7 7 7 15"/><path d="M9 20c0-5 1-9 3-9s3 4 3 9"/>',
  };
  const icon = (name) => {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.setAttribute('aria-hidden', 'true');
    s.setAttribute('class', 'svc-icon');
    s.innerHTML = ICONS[name] || ICONS.sparkle;
    return s;
  };
  const waIcon = () => {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.setAttribute('aria-hidden', 'true');
    s.setAttribute('class', 'wa-ico');
    s.innerHTML =
      '<path fill="currentColor" d="M12.04 2a9.9 9.9 0 0 0-8.5 14.9L2 22l5.25-1.38A9.9 9.9 0 1 0 12.04 2Zm0 1.8a8.1 8.1 0 1 1-4.3 15l-.3-.18-3.1.82.83-3.03-.2-.32A8.1 8.1 0 0 1 12.04 3.8Zm-3.2 3.9c-.18 0-.47.07-.72.34-.25.27-.95.93-.95 2.27s.98 2.64 1.11 2.82c.14.18 1.9 3.03 4.7 4.12 2.3.9 2.77.72 3.27.68.5-.05 1.6-.65 1.83-1.28.22-.64.22-1.18.16-1.3-.07-.11-.25-.18-.52-.31-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.61.14-.18.27-.7.88-.86 1.06-.16.18-.32.2-.59.07-.27-.14-1.15-.42-2.19-1.35-.8-.72-1.35-1.6-1.5-1.87-.16-.27-.02-.42.12-.55.12-.12.27-.32.4-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.6-1.5-.84-2.04-.2-.48-.4-.5-.6-.5Z"/>';
    return s;
  };

  /* ---------- Animações ao fazer scroll ---------- */
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const io =
    !reduce && 'IntersectionObserver' in window
      ? new IntersectionObserver(
          (entries) =>
            entries.forEach((e) => {
              if (e.isIntersecting) {
                e.target.classList.add('is-in');
                io.unobserve(e.target);
              }
            }),
          { rootMargin: '0px 0px -8% 0px', threshold: 0.08 }
        )
      : null;
  TN.observeReveal = (root = document) => {
    root.querySelectorAll('.reveal:not(.is-in)').forEach((n) => (io ? io.observe(n) : n.classList.add('is-in')));
  };

  /* ---------- Ligações de WhatsApp fixas ---------- */
  function initWaLinks() {
    document.querySelectorAll('[data-wa="general"]').forEach((a) => (a.href = TN.waLink(TN.msgGeneral())));
    document.querySelectorAll('[data-wa="testimonial"]').forEach((a) => (a.href = TN.waLink(TN.msgTestimonial())));
    document.querySelectorAll('[data-wa="directions"]').forEach(
      (a) => (a.href = TN.waLink(`Olá, ${SALON.name}! Podem indicar-me como chegar ao salão?`))
    );
    document.querySelectorAll('[data-wa-number]').forEach((n) => (n.textContent = SALON.whatsappDisplay));
    document.querySelectorAll('[data-maps]').forEach(
      (a) => (a.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(SALON.mapsQuery)}`)
    );
    const map = $('map-frame');
    if (map) map.src = `https://www.google.com/maps?q=${encodeURIComponent(SALON.mapsQuery)}&output=embed`;
  }

  /* ---------- Serviços ---------- */
  function renderServices() {
    const list = $('services-grid');
    const services = SERVICES.filter((s) => s.visible);
    services.forEach((s) => {
      const media = s.image
        ? el('img', { src: s.image, alt: `${s.name} — ${SALON.name}`, loading: 'lazy', decoding: 'async', width: 480, height: 360 })
        : null;
      const card = el('article', { class: 'svc reveal' }, [
        el('div', { class: 'svc-media' + (s.image ? '' : ' svc-media--icon') }, [media || icon(s.icon)]),
        el('div', { class: 'svc-body' }, [
          el('h3', { text: s.name }),
          el('p', { class: 'svc-desc', text: s.description }),
          el('p', { class: 'svc-price' + (s.price ? '' : ' is-muted'), text: s.price || 'Preço sob consulta' }),
          el(
            'a',
            {
              class: 'btn btn-outline btn-sm',
              href: TN.waLink(TN.msgService(s.name)),
              target: '_blank',
              rel: 'noopener',
            },
            [waIcon(), 'Quero marcar']
          ),
        ]),
      ]);
      list.append(card);
    });

    const sel = $('b-service');
    services.forEach((s) => sel.append(el('option', { value: s.name, text: s.name })));
    sel.append(el('option', { value: 'Outro (explico nas observações)', text: 'Outro (explico nas observações)' }));
  }

  /* ---------- Horário ---------- */
  function renderHours() {
    const ul = $('hours-list');
    ul.replaceChildren();
    const today = TN.nowInLuanda().day;
    HOURS.forEach((h) => {
      const li = el('li', { class: h.day === today ? 'is-today' : '' }, [
        el('span', { class: 'h-day', text: h.label }),
        el('span', { class: 'h-time', text: `${TN.fmtTime(h.open)} – ${TN.fmtTime(h.close)}` }),
      ]);
      if (h.day === today) li.setAttribute('aria-current', 'date');
      ul.append(li);
    });
    const st = TN.openStatus();
    document.querySelectorAll('[data-open-status]').forEach((n) => {
      n.textContent = st.text;
      n.classList.toggle('is-open', st.open);
      n.classList.toggle('is-closed', !st.open);
    });
  }

  /* ---------- Marcação pelo WhatsApp ---------- */
  function initBooking() {
    const form = $('booking-form');
    const date = $('b-date');
    const time = $('b-time');
    const hint = $('b-time-hint');
    const result = $('booking-result');

    const todayISO = TN.nowInLuanda().iso;
    date.min = todayISO;

    function updateHint() {
      if (!date.value) {
        hint.textContent = 'Escolhe primeiro a data para veres o horário desse dia.';
        time.removeAttribute('min');
        time.removeAttribute('max');
        return;
      }
      const h = TN.hoursFor(TN.dayOfISO(date.value));
      hint.textContent = `Horário nesse dia: ${TN.fmtTime(h.open)} – ${TN.fmtTime(h.close)}.`;
      time.min = h.open;
      time.max = h.close;
    }
    date.addEventListener('change', updateHint);
    updateHint();

    const fields = {
      name: $('b-name'),
      phone: $('b-phone'),
      service: $('b-service'),
      date,
      time,
      notes: $('b-notes'),
    };

    const setError = (key, msg) => {
      const f = fields[key];
      const err = $(`err-${key}`);
      if (!f || !err) return;
      err.textContent = msg || '';
      if (msg) f.setAttribute('aria-invalid', 'true');
      else f.removeAttribute('aria-invalid');
    };

    const normPhone = (raw) => {
      let d = raw.replace(/[\s\-().]/g, '');
      d = d.replace(/^\+?244/, '');
      return /^9\d{8}$/.test(d) ? d : null;
    };

    function validate() {
      const errors = {};
      const name = fields.name.value.trim();
      if (name.length < 2) errors.name = 'Escreve o teu nome.';
      const phone = normPhone(fields.phone.value);
      if (!phone) errors.phone = 'Indica um número de telemóvel angolano com 9 dígitos (ex.: 923 456 789).';
      if (!fields.service.value) errors.service = 'Escolhe o serviço pretendido.';

      if (!date.value) errors.date = 'Escolhe a data pretendida.';
      else if (date.value < todayISO) errors.date = 'Escolhe uma data a partir de hoje.';

      if (!time.value) errors.time = 'Escolhe a hora pretendida.';
      else if (date.value && !errors.date) {
        const h = TN.hoursFor(TN.dayOfISO(date.value));
        const m = TN.toMin(time.value);
        if (m < TN.toMin(h.open) || m >= TN.toMin(h.close)) {
          errors.time = `Nesse dia atendemos das ${TN.fmtTime(h.open)} às ${TN.fmtTime(h.close)}. Escolhe uma hora dentro do horário.`;
        } else if (date.value === todayISO && m <= TN.nowInLuanda().minutes) {
          errors.time = 'Essa hora já passou. Escolhe uma hora mais tarde.';
        }
      }
      if (fields.notes.value.length > 300) errors.notes = 'Usa no máximo 300 caracteres.';
      return { errors, name, phone };
    }

    ['name', 'phone', 'service', 'date', 'time', 'notes'].forEach((k) =>
      fields[k].addEventListener('input', () => setError(k, ''))
    );

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      result.hidden = true;
      result.replaceChildren();
      const { errors, name, phone } = validate();
      Object.keys(fields).forEach((k) => setError(k, errors[k]));
      const firstKey = Object.keys(errors)[0];
      if (firstKey) {
        fields[firstKey].focus();
        return;
      }
      const [y, m, d] = date.value.split('-');
      const weekday = TN.hoursFor(TN.dayOfISO(date.value)).label.toLowerCase();
      const msg = TN.msgBooking({
        name,
        phone: `+244 ${phone.slice(0, 3)} ${phone.slice(3, 6)} ${phone.slice(6)}`,
        service: fields.service.value,
        date: `${weekday}, ${d}/${m}/${y}`,
        time: TN.fmtTime(time.value),
        notes: fields.notes.value.trim(),
      });
      const url = TN.waLink(msg);
      // (com 'noopener' o navegador devolve sempre null, por isso corta-se a ligação à mão)
      const win = window.open(url, '_blank');
      if (win) win.opener = null;

      result.hidden = false;
      result.append(
        el('p', { class: 'result-title', text: 'Pedido preparado!' }),
        el('p', {
          text: win
            ? 'Abrimos o WhatsApp com os teus dados. Carrega em enviar para nos fazeres chegar o pedido.'
            : 'Não conseguimos abrir o WhatsApp automaticamente. Usa o botão abaixo para enviar o pedido.',
        }),
        el('p', {
          class: 'result-note',
          text: 'Isto é um pedido de marcação: a vaga só fica confirmada quando a Clínica de Beleza Tia Nina te responder no WhatsApp.',
        }),
        el('a', { class: 'btn btn-gold btn-sm', href: url, target: '_blank', rel: 'noopener' }, [waIcon(), 'Abrir o WhatsApp outra vez'])
      );
      result.focus();
    });
  }

  /* ---------- Testemunhos e redes sociais ---------- */
  function renderTestimonials() {
    const wrap = $('testimonials-list');
    const empty = $('testimonials-empty');
    if (!TESTIMONIALS.length) return;
    empty.hidden = true;
    TESTIMONIALS.forEach((t) =>
      wrap.append(
        el('figure', { class: 'quote reveal' }, [
          el('blockquote', { text: t.text }),
          el('figcaption', { text: t.name }),
        ])
      )
    );
  }

  function renderSocial() {
    const wrap = $('social');
    [
      ['Instagram', SALON.instagram],
      ['Facebook', SALON.facebook],
    ].forEach(([n, url]) => {
      wrap.append(
        url
          ? el('a', { href: url, target: '_blank', rel: 'noopener', text: n })
          : el('span', { class: 'is-muted', text: `${n} — em breve` })
      );
    });
  }

  /* ---------- Navegação ---------- */
  function initNav() {
    const btn = $('nav-toggle');
    const nav = $('site-nav');
    const header = document.querySelector('.site-header');
    const close = () => {
      nav.classList.remove('is-open');
      btn.setAttribute('aria-expanded', 'false');
    };
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', String(open));
    });
    nav.querySelectorAll('a').forEach((a) => a.addEventListener('click', close));
    document.addEventListener('keydown', (e) => e.key === 'Escape' && close());
    const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- Arranque ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    $('year').textContent = new Date().getFullYear();
    initWaLinks();
    renderServices();
    renderHours();
    renderTestimonials();
    renderSocial();
    initBooking();
    initNav();
    TN.observeReveal();
    TN.initGallery();
    setInterval(renderHours, 60 * 1000);
  });
})();
