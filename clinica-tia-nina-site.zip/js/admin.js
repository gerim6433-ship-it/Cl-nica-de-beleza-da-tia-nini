/* Painel da proprietária: entrar, enviar, pré-visualizar, publicar e remover fotografias. */
(function () {
  const TN = (window.TN = window.TN || {});
  const { el } = TN;
  const $ = (id) => document.getElementById(id);

  const MAX_ORIGINAL_MB = 25;
  const queue = []; // { file, url, node, category, caption }

  const show = (id, on) => ($(id).hidden = !on);
  const uid = () =>
    (window.crypto && crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2)).slice(0, 18);

  /* ---------- Estados do ecrã ---------- */
  function route() {
    show('not-configured', false);
    show('login', false);
    show('panel', false);
    $('logout').hidden = true;

    if (!TN.sb.isConfigured()) return show('not-configured', true);
    const s = TN.sb.session();
    if (!s) return show('login', true);

    show('panel', true);
    $('logout').hidden = false;
    $('who').textContent = s.email || 'proprietária';
    refreshList();
  }

  /* ---------- Entrar / sair ---------- */
  $('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('login-err');
    err.textContent = '';
    const email = $('l-email').value.trim();
    const pass = $('l-pass').value;
    if (!email || !pass) {
      err.textContent = 'Preenche o email e a palavra-passe.';
      return;
    }
    const btn = $('login-btn');
    btn.disabled = true;
    btn.textContent = 'A entrar…';
    try {
      await TN.sb.signIn(email, pass);
      $('l-pass').value = '';
      route();
    } catch (ex) {
      err.textContent = ex.name === 'AbortError' ? 'A ligação demorou demasiado. Tenta outra vez.' : ex.message;
    } finally {
      btn.disabled = false;
      btn.textContent = 'Entrar';
    }
  });

  $('logout').addEventListener('click', () => {
    TN.sb.signOut();
    route();
  });

  /* ---------- Reduzir imagens no navegador ---------- */
  function loadBitmap(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(url);
        resolve(img);
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('Não foi possível ler esta imagem.'));
      };
      img.src = url;
    });
  }

  async function shrink(img, maxSide, quality) {
    const ratio = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * ratio));
    const h = Math.max(1, Math.round(img.naturalHeight * ratio));
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d').drawImage(img, 0, 0, w, h);
    const toBlob = (type) => new Promise((res) => c.toBlob(res, type, quality));
    let blob = await toBlob('image/webp');
    if (!blob || blob.type !== 'image/webp') blob = await toBlob('image/jpeg');
    if (!blob) throw new Error('Não foi possível preparar a imagem.');
    return blob;
  }
  const ext = (blob) => (blob.type === 'image/webp' ? 'webp' : 'jpg');

  /* ---------- Pré-visualização ---------- */
  function addFiles(fileList) {
    const err = $('upload-err');
    err.textContent = '';
    const problems = [];
    [...fileList].forEach((file) => {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type)) return problems.push(`"${file.name}" não é JPG, PNG ou WebP.`);
      if (file.size > MAX_ORIGINAL_MB * 1024 * 1024) return problems.push(`"${file.name}" é demasiado grande (máx. ${MAX_ORIGINAL_MB} MB).`);

      const item = { file, url: URL.createObjectURL(file), category: 'penteados', caption: '' };
      const catSel = el(
        'select',
        { 'aria-label': 'Categoria da fotografia', onchange: (e) => (item.category = e.target.value) },
        TN.CATEGORIES.map((c) => el('option', { value: c.id, text: c.label }))
      );
      const cap = el('input', {
        type: 'text',
        maxlength: 140,
        placeholder: 'Legenda (opcional)',
        'aria-label': 'Legenda da fotografia',
        oninput: (e) => (item.caption = e.target.value),
      });
      item.msg = el('p', { class: 'pv-msg' });
      item.node = el('div', { class: 'pv' }, [
        el('img', { src: item.url, alt: `Pré-visualização: ${file.name}` }),
        el('div', { class: 'pv-body' }, [
          catSel,
          cap,
          item.msg,
          el('button', { type: 'button', class: 'pv-remove', text: 'Tirar da lista', onclick: () => removeFromQueue(item) }),
        ]),
      ]);
      queue.push(item);
      $('previews').append(item.node);
    });
    if (problems.length) err.textContent = problems.join(' ');
    syncPublish();
  }

  function removeFromQueue(item) {
    const i = queue.indexOf(item);
    if (i >= 0) queue.splice(i, 1);
    URL.revokeObjectURL(item.url);
    item.node.remove();
    syncPublish();
  }

  function syncPublish() {
    const n = queue.length;
    $('publish').hidden = n === 0;
    $('publish').textContent = n === 1 ? 'Publicar 1 fotografia' : `Publicar ${n} fotografias`;
  }

  $('file-input').addEventListener('change', (e) => {
    addFiles(e.target.files);
    e.target.value = '';
  });

  /* ---------- Publicar ---------- */
  $('publish').addEventListener('click', async () => {
    const btn = $('publish');
    const status = $('upload-status');
    const err = $('upload-err');
    err.textContent = '';
    btn.disabled = true;
    let ok = 0;
    const pending = [...queue];

    for (let i = 0; i < pending.length; i++) {
      const item = pending[i];
      status.textContent = `A enviar fotografia ${i + 1} de ${pending.length}…`;
      item.node.classList.remove('is-error');
      item.msg.textContent = 'A enviar…';
      try {
        const img = await loadBitmap(item.file);
        const [full, thumb] = await Promise.all([shrink(img, 1600, 0.82), shrink(img, 640, 0.78)]);
        const id = uid();
        const imagePath = `uploads/${id}.${ext(full)}`;
        const thumbPath = `uploads/${id}-sm.${ext(thumb)}`;
        await TN.sb.upload(imagePath, full);
        await TN.sb.upload(thumbPath, thumb);
        await TN.sb.insertItem({
          category: item.category,
          caption: item.caption.trim() || null,
          image_path: imagePath,
          thumb_path: thumbPath,
        });
        item.msg.textContent = 'Publicada ✓';
        item.node.classList.add('is-done');
        ok++;
        setTimeout(() => removeFromQueue(item), 900);
      } catch (ex) {
        item.node.classList.add('is-error');
        item.msg.textContent = ex.name === 'AbortError' ? 'A ligação demorou demasiado. Tenta outra vez.' : ex.message;
        if (/Sessão terminada/.test(ex.message)) {
          TN.sb.signOut();
          route();
          break;
        }
      }
    }
    btn.disabled = false;
    status.textContent = ok ? `${ok} fotografia(s) publicada(s). Já aparecem no site.` : '';
    if (ok < pending.length) err.textContent = 'Algumas fotografias não foram publicadas. Vê a mensagem em cada uma e tenta outra vez.';
    refreshList();
  });

  /* ---------- Fotografias publicadas ---------- */
  async function refreshList() {
    const box = $('published');
    const st = $('list-status');
    st.textContent = 'A carregar…';
    try {
      const rows = await TN.sb.listItems();
      box.replaceChildren();
      show('import-box', rows.length === 0);
      st.textContent = rows.length
        ? `${rows.length} fotografia(s) publicada(s).`
        : 'Ainda não há fotografias no painel. O site mostra, entretanto, as fotografias iniciais.';
      rows.forEach((r) => {
        box.append(
          el('div', { class: 'pub' }, [
            el('img', { src: TN.sb.publicUrl(r.thumb_path), alt: r.caption || TN.categoryLabel(r.category), loading: 'lazy' }),
            el('div', { class: 'pub-body' }, [
              el('strong', { text: TN.categoryLabel(r.category) }),
              el('span', { text: r.caption || 'Sem legenda' }),
              el('button', { type: 'button', class: 'btn btn-outline', text: 'Remover', onclick: () => remove(r) }),
            ]),
          ])
        );
      });
    } catch (ex) {
      st.textContent = 'Não foi possível carregar a lista. Verifica a ligação e tenta outra vez.';
    }
  }

  async function remove(row) {
    if (!window.confirm('Remover esta fotografia da galeria? Esta ação não pode ser desfeita.')) return;
    try {
      await TN.sb.deleteItem(row);
      refreshList();
    } catch (ex) {
      $('list-status').textContent = ex.message;
      if (/Sessão terminada/.test(ex.message)) {
        TN.sb.signOut();
        route();
      }
    }
  }

  /* ---------- Importar as fotografias iniciais ---------- */
  $('import-seed').addEventListener('click', async () => {
    const btn = $('import-seed');
    const st = $('list-status');
    btn.disabled = true;
    try {
      const seeds = [...TN.SEED_GALLERY].reverse(); // a primeira da lista fica a mais recente
      for (let i = 0; i < seeds.length; i++) {
        const s = seeds[i];
        st.textContent = `A importar ${i + 1} de ${seeds.length}…`;
        const [full, thumb] = await Promise.all(
          [`gallery/${s.name}.webp`, `gallery/${s.name}-sm.webp`].map(async (u) => {
            const r = await fetch(u);
            if (!r.ok) throw new Error('Não foi possível ler as fotografias iniciais. Abre o site a partir do endereço publicado (não do ficheiro no computador).');
            return r.blob();
          })
        );
        await TN.sb.upload(`seed/${s.name}.webp`, full);
        await TN.sb.upload(`seed/${s.name}-sm.webp`, thumb);
        await TN.sb.insertItem({
          category: s.category,
          caption: s.caption,
          image_path: `seed/${s.name}.webp`,
          thumb_path: `seed/${s.name}-sm.webp`,
        });
      }
    } catch (ex) {
      st.textContent = ex.message;
    } finally {
      btn.disabled = false;
      refreshList();
    }
  });

  document.addEventListener('DOMContentLoaded', route);
})();
