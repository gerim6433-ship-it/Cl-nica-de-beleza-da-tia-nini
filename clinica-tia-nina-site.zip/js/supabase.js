/*
 * Ligação ao Supabase por API REST (sem bibliotecas externas).
 * Usa APENAS a chave pública "anon". A segurança está nas políticas (RLS)
 * definidas em supabase/setup.sql: qualquer pessoa pode VER a galeria,
 * mas só a conta da proprietária pode adicionar ou remover fotografias.
 */
(function () {
  const TN = (window.TN = window.TN || {});
  const SESSION_KEY = 'tn_admin_session';

  const cfg = () => TN.SUPABASE || {};
  const base = () => (cfg().url || '').replace(/\/+$/, '');
  TN.sb = {};

  TN.sb.isConfigured = () => Boolean(cfg().url && cfg().anonKey);

  TN.sb.publicUrl = (path) =>
    `${base()}/storage/v1/object/public/gallery/${path.split('/').map(encodeURIComponent).join('/')}`;

  const anonHeaders = () => ({ apikey: cfg().anonKey, Authorization: `Bearer ${cfg().anonKey}` });

  async function fetchTimeout(url, opts = {}, ms = 8000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try {
      return await fetch(url, { ...opts, signal: ctrl.signal });
    } finally {
      clearTimeout(t);
    }
  }

  /* ---------- Leitura pública ---------- */
  TN.sb.listItems = async () => {
    const r = await fetchTimeout(`${base()}/rest/v1/gallery_items?select=*&order=created_at.desc`, {
      headers: anonHeaders(),
    });
    if (!r.ok) throw new Error(`Galeria indisponível (${r.status})`);
    return r.json();
  };

  /* ---------- Sessão da proprietária ---------- */
  const loadSession = () => {
    try {
      return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
    } catch (e) {
      return null;
    }
  };
  const saveSession = (s) => {
    try {
      if (s) localStorage.setItem(SESSION_KEY, JSON.stringify(s));
      else localStorage.removeItem(SESSION_KEY);
    } catch (e) {
      /* armazenamento indisponível: a sessão dura só enquanto a página estiver aberta */
    }
    TN.sb._mem = s;
  };
  TN.sb.session = () => TN.sb._mem || loadSession();

  const toSession = (j) => ({
    access_token: j.access_token,
    refresh_token: j.refresh_token,
    email: (j.user && j.user.email) || '',
  });

  TN.sb.signIn = async (email, password) => {
    const r = await fetchTimeout(`${base()}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { apikey: cfg().anonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      const bad = r.status === 400 || r.status === 401;
      throw new Error(bad ? 'Email ou palavra-passe incorretos.' : 'Não foi possível entrar. Tenta outra vez.');
    }
    saveSession(toSession(j));
    return TN.sb.session();
  };

  TN.sb.signOut = () => saveSession(null);

  async function refresh() {
    const s = TN.sb.session();
    if (!s || !s.refresh_token) return false;
    const r = await fetchTimeout(`${base()}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { apikey: cfg().anonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: s.refresh_token }),
    });
    if (!r.ok) {
      saveSession(null);
      return false;
    }
    saveSession(toSession(await r.json()));
    return true;
  }

  /** Pedido autenticado; renova a sessão uma vez se tiver expirado. */
  async function authed(url, opts = {}, ms = 30000) {
    const go = () => {
      const s = TN.sb.session();
      if (!s) throw new Error('Sessão terminada. Entra outra vez.');
      return fetchTimeout(
        url,
        { ...opts, headers: { apikey: cfg().anonKey, Authorization: `Bearer ${s.access_token}`, ...(opts.headers || {}) } },
        ms
      );
    };
    let r = await go();
    if (r.status === 401 && (await refresh())) r = await go();
    if (r.status === 401) throw new Error('Sessão terminada. Entra outra vez.');
    return r;
  }

  /* ---------- Escrita (só a proprietária) ---------- */
  TN.sb.upload = async (path, blob) => {
    const r = await authed(`${base()}/storage/v1/object/gallery/${path.split('/').map(encodeURIComponent).join('/')}`, {
      method: 'POST',
      headers: { 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'false' },
      body: blob,
    });
    if (!r.ok) throw new Error(r.status === 403 ? 'Sem permissão para enviar fotografias.' : `Falha no envio (${r.status}).`);
  };

  TN.sb.insertItem = async (row) => {
    const r = await authed(`${base()}/rest/v1/gallery_items`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Prefer: 'return=representation' },
      body: JSON.stringify(row),
    });
    if (!r.ok) throw new Error(r.status === 403 ? 'Sem permissão para guardar a fotografia.' : `Falha ao guardar (${r.status}).`);
    return (await r.json())[0];
  };

  TN.sb.deleteItem = async (item) => {
    const r = await authed(`${base()}/rest/v1/gallery_items?id=eq.${encodeURIComponent(item.id)}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=representation' },
    });
    if (!r.ok) throw new Error(`Falha ao remover (${r.status}).`);
    const removed = await r.json();
    if (!removed.length) throw new Error('Sem permissão para remover esta fotografia.');
    // Remove também os ficheiros (se falhar, a foto já saiu da galeria pública)
    await authed(`${base()}/storage/v1/object/gallery`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefixes: [item.image_path, item.thumb_path] }),
    }).catch(() => {});
  };
})();
