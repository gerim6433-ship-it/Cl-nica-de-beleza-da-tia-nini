-- ============================================================
-- Clínica de Beleza Tia Nina — configuração da galeria no Supabase
-- Cola este ficheiro inteiro em: Supabase → SQL Editor → New query → Run
--
-- ANTES DE EXECUTAR: troca  EMAIL_DA_PROPRIETARIA@exemplo.com
-- (aparece 5 vezes) pelo email da conta da proprietária.
-- Só essa conta poderá adicionar ou remover fotografias.
-- ============================================================

-- 1) Tabela das fotografias -----------------------------------
create table if not exists public.gallery_items (
  id          uuid primary key default gen_random_uuid(),
  category    text not null check (category in ('penteados','unhas','maquilhagem','perucas','salao','outros')),
  caption     text check (caption is null or char_length(caption) <= 140),
  image_path  text not null,
  thumb_path  text not null,
  created_at  timestamptz not null default now()
);

alter table public.gallery_items enable row level security;

drop policy if exists "galeria: todos podem ver"      on public.gallery_items;
drop policy if exists "galeria: so a dona adiciona"   on public.gallery_items;
drop policy if exists "galeria: so a dona remove"     on public.gallery_items;

create policy "galeria: todos podem ver"
  on public.gallery_items for select
  to anon, authenticated
  using (true);

create policy "galeria: so a dona adiciona"
  on public.gallery_items for insert
  to authenticated
  with check ((auth.jwt() ->> 'email') = 'EMAIL_DA_PROPRIETARIA@exemplo.com');

create policy "galeria: so a dona remove"
  on public.gallery_items for delete
  to authenticated
  using ((auth.jwt() ->> 'email') = 'EMAIL_DA_PROPRIETARIA@exemplo.com');

-- 2) Pasta (bucket) das imagens --------------------------------
-- Pública para leitura (as fotos aparecem no site), limite de 5 MB
-- por ficheiro e só imagens.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('gallery', 'gallery', true, 5242880, array['image/webp','image/jpeg','image/png'])
on conflict (id) do update
  set public = true,
      file_size_limit = 5242880,
      allowed_mime_types = array['image/webp','image/jpeg','image/png'];

drop policy if exists "fotos: so a dona envia"  on storage.objects;
drop policy if exists "fotos: so a dona remove" on storage.objects;

create policy "fotos: so a dona envia"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'gallery' and (auth.jwt() ->> 'email') = 'EMAIL_DA_PROPRIETARIA@exemplo.com');

create policy "fotos: so a dona remove"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'gallery' and (auth.jwt() ->> 'email') = 'EMAIL_DA_PROPRIETARIA@exemplo.com');

-- Nota: não existe política de "select" em storage.objects de propósito.
-- Assim, o endereço direto de cada foto funciona (bucket público), mas
-- ninguém consegue listar todos os ficheiros do bucket.
